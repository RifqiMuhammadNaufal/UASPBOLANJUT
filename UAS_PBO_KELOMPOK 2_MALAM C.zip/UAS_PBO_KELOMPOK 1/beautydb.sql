-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Jul 2021 pada 11.56
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `beautydb`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(3, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `creambath`
--

CREATE TABLE `creambath` (
  `idcream` int(10) NOT NULL,
  `namacream` varchar(255) NOT NULL,
  `alamatcream` varchar(255) NOT NULL,
  `tanggalcream` varchar(255) NOT NULL,
  `jamcream` varchar(255) NOT NULL,
  `jenispesanancream` varchar(255) NOT NULL,
  `hargacream` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `creambath`
--

INSERT INTO `creambath` (`idcream`, `namacream`, `alamatcream`, `tanggalcream`, `jamcream`, `jenispesanancream`, `hargacream`) VALUES
(1, 'rijal', 'simpang', '12/12/2021', '21.00', 'Creambath', 'Rp. 50.000'),
(2, 'Sukinem', 'Cituba', '22/02/2021', '11.00', 'Creambath', 'Rp. 50.000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `gradu`
--

CREATE TABLE `gradu` (
  `id` int(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  `jam` varchar(255) NOT NULL,
  `jenispesanan` varchar(255) NOT NULL,
  `harga` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `gradu`
--

INSERT INTO `gradu` (`id`, `nama`, `alamat`, `tanggal`, `jam`, `jenispesanan`, `harga`) VALUES
(1, 'memet', 'ciwangi', '21/10/2021', '21.00', 'Only Make Up', 'Rp. 200.000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ptgrambut`
--

CREATE TABLE `ptgrambut` (
  `id` int(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  `jam` varchar(128) NOT NULL,
  `jenispesanan` varchar(255) NOT NULL,
  `harga` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `ptgrambut`
--

INSERT INTO `ptgrambut` (`id`, `nama`, `alamat`, `tanggal`, `jam`, `jenispesanan`, `harga`) VALUES
(1, 'opang', 'rumah', '12/12/2021', '21/00', 'Potong Rambut', 'Rp. 30.000'),
(2, 'opang', 'mana aja', '12/12/01', '22.00', 'Potong Rambut', 'Rp. 30.000'),
(3, 'rijal', 'simpang', '12/12/2020', '10.00', 'Potong Rambut', 'Rp. 30.000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `spa`
--

CREATE TABLE `spa` (
  `idspa` int(10) NOT NULL,
  `namaspa` varchar(255) NOT NULL,
  `alamatspa` varchar(255) NOT NULL,
  `tanggalspa` varchar(255) NOT NULL,
  `jamspa` varchar(255) NOT NULL,
  `jenispesananspa` varchar(255) NOT NULL,
  `hargaspa` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `spa`
--

INSERT INTO `spa` (`idspa`, `namaspa`, `alamatspa`, `tanggalspa`, `jamspa`, `jenispesananspa`, `hargaspa`) VALUES
(1, 'Lia', 'Pasjum', '12/12/2021', '10.00', 'Spa', 'Rp. 75.000'),
(2, 'Rudianan', 'Jauh weh pokona', '10/10/2021', '12.00', 'Spa', 'Rp. 75.000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `wedding`
--

CREATE TABLE `wedding` (
  `id` int(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  `jam` varchar(255) NOT NULL,
  `jenispesanan` varchar(255) NOT NULL,
  `harga` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `wedding`
--

INSERT INTO `wedding` (`id`, `nama`, `alamat`, `tanggal`, `jam`, `jenispesanan`, `harga`) VALUES
(1, 'Udin', 'Pasar Rebo', '10/10/2021', '21.00', 'Only Make Up', 'Rp. 350.000');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `creambath`
--
ALTER TABLE `creambath`
  ADD PRIMARY KEY (`idcream`);

--
-- Indeks untuk tabel `gradu`
--
ALTER TABLE `gradu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `ptgrambut`
--
ALTER TABLE `ptgrambut`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `spa`
--
ALTER TABLE `spa`
  ADD PRIMARY KEY (`idspa`);

--
-- Indeks untuk tabel `wedding`
--
ALTER TABLE `wedding`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `creambath`
--
ALTER TABLE `creambath`
  MODIFY `idcream` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `gradu`
--
ALTER TABLE `gradu`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `spa`
--
ALTER TABLE `spa`
  MODIFY `idspa` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `wedding`
--
ALTER TABLE `wedding`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
